let totalvalue = 2000;
let discountedpercentage = 20;

let discountedvalue = totalvalue - (discountedprcentage/100) * totalvalue;
console.log("The final price after discount is : Rs." + discountedvalue);
