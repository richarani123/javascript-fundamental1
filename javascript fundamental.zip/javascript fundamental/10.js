
let arr = [1,8,-5,89,73,-6,-98,-76];
for  (let i = 0; i < arr.length; i++)
{
if (arr [i] < 0){
    continue;
}
console.log(arr[i]);
}
