let username = "Admin";
let password = 1234;
if(username){
    if(password){
        console.log("Login Successfully");
    }
    else{
        console.log("Invalid Credentials");
    }
}


