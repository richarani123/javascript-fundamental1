let numberofChilds = 5;
let numberofAdults = 8;
let numberofSeniors = 20;

let childTicketprice = 100;
let adultTicketprice = 150;
let seniorTicketprice = 120;

 let totalprice = 
numberofChilds * childTicketprice + numberofAdults * adultTicketprice + numberofSeniors * seniorTicketprice ;
console.log(`The total ticket price is ${totalprice}`);