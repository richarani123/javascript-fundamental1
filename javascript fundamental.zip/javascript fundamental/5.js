let typeOfPackage = "overnight"
switch (typeOfPackage) {
    case "standard":
        console.log("Your package will be delivered after 3-5 days");
        break;
    case "express":
        console.log("Your package will be delivered after 2-3 days");
        break;
    case "overnight":
        console.log("Your package will be delivered by  next day")        
        break;
    default:
        console.log("found wrong delivery credentials");
}