let name = "richa"
let age = 20;
let email = "richarani1276@gmail.com"

if (typeof name !== "string") {
    console.log("name should be a string...");
}
else if (typeof age !== "number") {
 console.log("age should be a number...");
}
else if (typeof email !== "string") {
console.log("email should be a string...");
}else{
    console.log("yess!!! All the fields are proper");
}