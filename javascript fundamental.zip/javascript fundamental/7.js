let shoppingList = [
    "pen",
    "pecil",
    "eraser",
    "book",
    "sprite",
    "cold drink",
    "pizza",
];
for (let i = 0; i < shoppingList.length; i++){
    console.log(shoppingList[i]);
}