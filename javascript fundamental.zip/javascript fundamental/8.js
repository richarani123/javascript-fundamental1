console.log("conting from 0 TO 10");
let i = 0;

while (i <= 10) {
    console.log(i);
    i++;
    
}