const arr = ["pw",19 , 999, 89076, "richa", "rani", "ms world",];
for (let i = 0; i < arr.length; i++){
if (typeof arr[i] ==="string") {
    console.log (`found the first string: ${arr[i]}`);
    break;
}
}
